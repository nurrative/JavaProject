package com.company;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.KeyStroke;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;



public class Viewer  implements ListSelectionListener {
    private JTextArea textArea;
    private JFrame frame;
    JDialog dialog;
    Controller controller;

    JTextField tFont;
    JTextField tFontStyle;
    JTextField tFontSize;

    public Viewer(Controller controller) {
        this.controller = controller;

        ImageIcon imageOpen = new ImageIcon("images/Open.png"), imageNew = new ImageIcon("images/New.png"), imageSave = new ImageIcon("images/Save.png"),
                imageSaveAs = new ImageIcon("images/SaveAs.png"), imagePrint = new ImageIcon("images/Print.png"), imageStatusBar = new ImageIcon("images/StatusBar.png"),
                imageExit = new ImageIcon("images/Exit.png"), imageCut = new ImageIcon("images/Cut.png"), imageAbout = new ImageIcon("images/Info.png"),
                imageCopy = new ImageIcon("images/Copy.png"), imagePaste = new ImageIcon("images/Paste.png"), imageDelete = new ImageIcon("images/Delete.png"),
                imageHelp = new ImageIcon("images/Help.png"), imageWordWrap = new ImageIcon("images/Word_Wrap.png"), imageSelectAll = new ImageIcon("images/Select_All.png"),
                imageTime = new ImageIcon("images/Date.png"), imageFont = new ImageIcon("images/Font.png");

        BorderLayout borderLayout = new BorderLayout();

        JMenuItem newDocument = new JMenuItem("New", imageNew);
        newDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
        newDocument.addActionListener(controller);
        newDocument.setActionCommand("New_Document");

        JMenuItem openDocument = new JMenuItem("Open ...", imageOpen);
        openDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        openDocument.addActionListener(controller);
        openDocument.setActionCommand("Open_Document");

        JMenuItem saveDocument = new JMenuItem("Save", imageSave);
        saveDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
        saveDocument.addActionListener(controller);
        saveDocument.setActionCommand("Save_Document");

        JMenuItem saveAsDocument = new JMenuItem("Save as ", imageSaveAs);
        saveAsDocument.addActionListener(controller);
        saveAsDocument.setActionCommand("SaveAs_Document");

        JMenuItem printDocument = new JMenuItem("Print", imagePrint);
        printDocument.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
        printDocument.addActionListener(controller);
        printDocument.setActionCommand("Print_Document");

        JMenuItem exitDocument = new JMenuItem("Exit", imageExit);
        exitDocument.addActionListener(controller);
        exitDocument.setActionCommand("Exit_programm");

        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        fileMenu.add(newDocument);
        fileMenu.add(openDocument);
        fileMenu.add(saveDocument);
        fileMenu.add(saveAsDocument);
        fileMenu.addSeparator();
        fileMenu.add(printDocument);
        fileMenu.addSeparator();
        fileMenu.add(exitDocument);

        JMenuItem cutEdit = new JMenuItem("Cut", imageCut);
        cutEdit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
        cutEdit.addActionListener(controller);
        cutEdit.setActionCommand("Cut_Edit");

        JMenuItem copyEdit = new JMenuItem("Copy", imageCopy);
        copyEdit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
        copyEdit.addActionListener(controller);
        copyEdit.setActionCommand("Copy_Edit");

        JMenuItem pasteEdit = new JMenuItem("Paste", imagePaste);
        pasteEdit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
        pasteEdit.addActionListener(controller);
        pasteEdit.setActionCommand("Paste_Edit");

        JMenuItem deleteEdit = new JMenuItem("Delete", imageDelete);
        deleteEdit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        deleteEdit.addActionListener(controller);
        deleteEdit.setActionCommand("Delete_Edit");


        JMenuItem selectAllEdit = new JMenuItem("Select All", imageSelectAll);
        selectAllEdit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
        selectAllEdit.addActionListener(controller);
        selectAllEdit.setActionCommand("Select_All_Edit");
        JMenuItem timeDateEdit = new JMenuItem("Time/Date", imageTime);
        timeDateEdit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        timeDateEdit.addActionListener(controller);
        timeDateEdit.setActionCommand("Time_Date_Edit");


        JMenu editMenu = new JMenu("Edit");
        editMenu.setMnemonic(KeyEvent.VK_E);

        editMenu.add(cutEdit);
        editMenu.add(copyEdit);
        editMenu.add(pasteEdit);
        editMenu.add(deleteEdit);
        editMenu.addSeparator();
        editMenu.add(selectAllEdit);
        editMenu.add(timeDateEdit);

        JCheckBoxMenuItem wordWrapFormat = new JCheckBoxMenuItem("Word Wrap", imageWordWrap);
        wordWrapFormat.setMnemonic(KeyEvent.VK_C);
        wordWrapFormat.addActionListener(controller);
        wordWrapFormat.setActionCommand("Word_Wrap");
        JMenuItem fontFormat = new JMenuItem("Font ...", imageFont);
        fontFormat.addActionListener(controller);
        fontFormat.setActionCommand("Font_Format");
        JMenu formatMenu = new JMenu("Format");
        formatMenu.setMnemonic(KeyEvent.VK_O);
        formatMenu.add(wordWrapFormat);
        formatMenu.add(fontFormat);

        JCheckBoxMenuItem statusBarView = new JCheckBoxMenuItem("Status Bar", imageStatusBar);
        statusBarView.setMnemonic(KeyEvent.VK_C);
        JMenu viewMenu = new JMenu("View");
        viewMenu.setMnemonic(KeyEvent.VK_V);
        viewMenu.add(statusBarView);

        JMenuItem seeHelpHelp = new JMenuItem("See Help", imageHelp);
        seeHelpHelp.addActionListener(controller);
        seeHelpHelp.setActionCommand("Help");
        JMenuItem aboutHelp = new JMenuItem("About programm", imageAbout);
        aboutHelp.addActionListener(controller);
        aboutHelp.setActionCommand("About");
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        helpMenu.add(seeHelpHelp);
        helpMenu.addSeparator();
        helpMenu.add(aboutHelp);

        JMenuBar menuBar = new JMenuBar();
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(formatMenu);
        menuBar.add(viewMenu);
        menuBar.add(helpMenu);

        JToolBar toolBar = new JToolBar();
        JButton newDocumentButton = new JButton(imageNew);
        newDocumentButton.addActionListener(controller);
        newDocumentButton.setActionCommand("New_Document");
        JButton openDocumentButton = new JButton(imageOpen);
        openDocumentButton.addActionListener(controller);
        openDocumentButton.setActionCommand("Open_Document");
        JButton saveDocumentButton = new JButton(imageSave);
        saveDocumentButton.addActionListener(controller);
        saveDocumentButton.setActionCommand("Save_Document");
        JButton saveAsDocumentButton = new JButton(imageSaveAs);
        saveAsDocumentButton.addActionListener(controller);
        saveAsDocumentButton.setActionCommand("SaveAs_Document");
        JButton printDocumentButton = new JButton(imagePrint);
        printDocumentButton.addActionListener(controller);
        printDocumentButton.setActionCommand("Print_Document");
        JButton cutEditButton = new JButton(imageCut);
        cutEditButton.addActionListener(controller);
        cutEditButton.setActionCommand("Cut_Edit");
        JButton copyEditButton = new JButton(imageCopy);
        copyEditButton.addActionListener(controller);
        copyEditButton.setActionCommand("Copy_Edit");
        JButton pasteEditButton = new JButton(imagePaste);
        pasteEditButton.addActionListener(controller);
        pasteEditButton.setActionCommand("Paste_Edit");
        JButton deleteEditButton = new JButton(imageDelete);
        deleteEditButton.addActionListener(controller);
        deleteEditButton.setActionCommand("Delete_Edit");
        JButton exitDocumentButton = new JButton(imageExit);
        exitDocumentButton.addActionListener(controller);
        exitDocumentButton.setActionCommand("Exit_programm");

        toolBar.add(newDocumentButton, openDocumentButton);
        toolBar.addSeparator();
        toolBar.add(openDocumentButton);
        toolBar.addSeparator();
        toolBar.add(saveDocumentButton);
        toolBar.addSeparator();
        toolBar.add(saveAsDocumentButton);
        toolBar.addSeparator();
        toolBar.add(printDocumentButton);
        toolBar.addSeparator();
        toolBar.addSeparator();
        toolBar.add(cutEditButton);
        toolBar.addSeparator();
        toolBar.add(copyEditButton);
        toolBar.addSeparator();
        toolBar.add(pasteEditButton);
        toolBar.add(deleteEditButton);
        toolBar.addSeparator();
        toolBar.add(exitDocumentButton);
        toolBar.addSeparator();
        toolBar.setFloatable(false);

        textArea = new JTextArea();
        JScrollPane scroll = new JScrollPane(textArea);

        frame = new JFrame("Notepad");
        frame.setIconImage(new ImageIcon("images/logo.png").getImage());
        frame.setSize(600, 600);
        frame.setLocation(150, 100);
        frame.setLayout(borderLayout);
        frame.add("North", toolBar);
        frame.add("Center", scroll);
        frame.setJMenuBar(menuBar);
        frame.setVisible(true);

    }

    public JTextArea getTextArea() {

        return textArea;
    }

    public String getTextFromTextArea() {
        String text = textArea.getText();
        return text;
    }

    public void setTextToTextArea(String value) {
        textArea.setText(value);
    }

    public JFrame getFrame() {
        return frame;
    }


    public void aboutDialog() {
        JDialog dialog;

        ImageIcon K = new ImageIcon("images/Kalzira.jpeg"), N = new ImageIcon("images/Nursultan.jpg"), IAU = new ImageIcon("images/iau.png"), Com = new ImageIcon("images/com.png");
        JLabel labelAbout = new JLabel("The project is executed by:"), label1 = new JLabel(K), label2 = new JLabel(N), labelIau = new JLabel(IAU), labelCom = new JLabel(Com);

        JLabel labelK = new JLabel("Kalzira Sabytakunova                     Nursultan Kasymbekov");
        dialog = new JDialog(frame, "About Notepad", true);
        dialog.setLocation(frame.getLocation().x + 50, frame.getLocation().y + 50);
        dialog.setSize(500, 500);

        labelK.setBounds(70, 410, 400, 15);
        label1.setBounds(10, 70, 240, 400);
        label2.setBounds(200, 70, 240, 400);
        labelIau.setBounds(70, 10, 100, 100);
        labelCom.setBounds(200, 10, 250, 100);
        labelAbout.setBounds(150, 115, 200, 15);

        dialog.add(labelIau);
        dialog.add(labelCom);
        dialog.add(label1);
        dialog.add(label2);
        dialog.add(labelAbout);
        dialog.add(labelK);

        dialog.setLayout(null);
        dialog.setResizable(false);
        dialog.setVisible(true);
    }

    public void showFontDialog() {


        JPanel panelA = new JPanel();

        JPanel panelLeft = new JPanel();
        panelLeft.setLayout(new BoxLayout(panelLeft, BoxLayout.PAGE_AXIS));

        panelLeft.add(new JLabel("Font:             "));
        tFont = new JTextField("Impact");


        panelLeft.add(tFont);
        DefaultListModel listModel = new DefaultListModel();
        listModel.addElement("Impact");
        listModel.addElement("Times New Roman");
        listModel.addElement("Calibri");
        listModel.addElement("Arial");


        //Create the list and put it in a scroll pane.
        JList list = new JList(listModel);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setSelectedIndex(0);
        list.addListSelectionListener(this);
        list.setVisibleRowCount(3);
        JScrollPane listScrollPane = new JScrollPane(list);
        panelLeft.add(listScrollPane);


        JPanel panelCenter = new JPanel();
        panelCenter.setLayout(new BoxLayout(panelCenter, BoxLayout.PAGE_AXIS));

        panelCenter.add(new JLabel("Font Style: "));
        tFontStyle = new JTextField("Regular");
        panelCenter.add(tFontStyle);
        DefaultListModel listModel1 = new DefaultListModel();
        listModel1.addElement("Bold");
        listModel1.addElement("Italic");
        listModel1.addElement("Regular");


        //Create the list and put it in a scroll pane.
        JList list1 = new JList(listModel1);
        list1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list1.setSelectedIndex(0);
        list1.addListSelectionListener(this);

        list1.setVisibleRowCount(3);
        JScrollPane listScrollPane1 = new JScrollPane(list1);

        panelCenter.add(listScrollPane1);


        JPanel panelRight = new JPanel();
        panelRight.setLayout(new BoxLayout(panelRight, BoxLayout.PAGE_AXIS));

        panelRight.add(new JLabel("Size:   "));

        tFontSize = new JTextField("12");
        panelRight.add(tFontSize);
        DefaultListModel listModel2 = new DefaultListModel();
        listModel2.addElement("12");
        listModel2.addElement("14");
        listModel2.addElement("16");
        listModel2.addElement("18");
        listModel2.addElement("20");


        //Create the list and put it in a scroll pane.
        JList list2 = new JList(listModel2);
        list2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list2.setSelectedIndex(0);
        list2.setVisibleRowCount(3);

        list2.addListSelectionListener(this);
        JScrollPane listScrollPane2 = new JScrollPane(list2);

        panelRight.add(listScrollPane2);


        panelA.add(panelLeft);
        panelA.add(panelCenter);
        panelA.add(panelRight);


        JButton buttonOk = new JButton("OK");
        buttonOk.addActionListener(controller);



        dialog = new JDialog(frame, "Font", true);
        dialog.setLocation(frame.getLocation().x + 100, frame.getLocation().y + 100);
        dialog.setSize(300, 200);

        dialog.add("South", buttonOk);

        dialog.add("Center", panelA);

        dialog.setResizable(false);


        dialog.setVisible(true);


    }

    @Override
    public void valueChanged(ListSelectionEvent yep) {
        String arr;
        JList list = (JList) yep.getSource();
        int selections[] = list.getSelectedIndices();
        Object selectedValues[] = list.getSelectedValues();
        for (int i = 0, n = selections.length; i < n; i++) {
            arr = (""+selectedValues[i]);
            switch (arr){
                case "Impact":
                    tFont.setText(arr);
                    break;
                case "Times New Roman":
                    tFont.setText(arr);
                    break;

                case "Arial":
                    tFont.setText(arr);
                    break;
                case "Calibri":
                    tFont.setText(arr);
                    break;
                case "Regular":
                    tFontStyle.setText(arr);
                    break;
                case "Bold":
                    tFontStyle.setText(arr);
                    break;

                case "Italic":
                    tFontStyle.setText(arr);
                    break;
                case "12":
                    tFontSize.setText(arr);
                    break;
                case "14":
                    tFontSize.setText(arr);
                    break;
                case "16":
                    tFontSize.setText(arr);
                    break;
                case "18":
                    tFontSize.setText(arr);
                    break;
            }
        }
    }
}

