package com.company;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.print.*;
import java.io.*;

public class Print implements Printable {

    String buffer = "";


    Print () {

        open();

        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(this);
        boolean ok = job.printDialog();
        if (ok) {
            try {
                job.print();
            } catch (PrinterException ex) {
                System.out.println("");
            }
        }


    }

    public int print(Graphics g, PageFormat pf, int page) throws PrinterException {


        String txt = buffer;


        if (page > 0) {
            return NO_SUCH_PAGE;
        }


        Graphics2D g2d = (Graphics2D)g;
        g2d.translate(pf.getImageableX(), pf.getImageableY());



        double wid = pf.getImageableWidth();
        double hei = pf.getImageableHeight();


        int stepX = 30;
        int stepY = 30;



        for(int i=0; i<txt.length(); i++){

            char symbol = txt.charAt(i);

            FontMetrics fm = g.getFontMetrics();
            int w = fm.stringWidth("" + txt.charAt(i));

            if(stepY < hei-30){
                if(stepX > ((int)wid-30)){
                    stepX = 30;
                    stepY = stepY + 15;


                } else {
                    if(symbol == '\n'){
                        stepX = 30;
                        stepY = stepY + 15;

                    }

                    g.drawString("" + symbol, stepX, stepY);
                    stepX = stepX + w;
                }


            }
        }


        return PAGE_EXISTS;
    }

    private boolean open() {

        try {

            JFileChooser fc = new JFileChooser();
            int returnVal = fc.showOpenDialog(new JFrame());

            if(returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();

                FileReader fr = new FileReader(file);

                BufferedReader inputStream = new BufferedReader(fr);

                String line;
                while ((line = inputStream.readLine()) != null) {
                    buffer = buffer + line + "\n";

                }

                String fileName = file.toString();

                return true;
            }

        } catch(IOException ioe) {
            System.out.println(ioe);
            return false;
        }

        return false;

    }
}
