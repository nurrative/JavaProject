package com.company;
import com.sun.jndi.toolkit.url.Uri;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.net.URI;
import java.util.Date;
import java.awt.Font;


public class Controller implements ActionListener {

    private Viewer viewer;
    private String fileName;
    String buffer;





    public Controller() {
        viewer = new Viewer(this);


        fileName="Untitled";


    }


    public void actionPerformed(ActionEvent event) {

        String cmd = event.getActionCommand();
        System.out.println(cmd);
        switch(cmd) {
            case "New_Document":
                newDocument();
                break;
            case "Open_Document":
                open();
                break;

            case "SaveAs_Document":
                saveAs();
                break;
            case "Save_Document":
                save();
                break;

            case "Copy_Edit":
                viewer.getTextArea().copy();
                break;
            case "Select_All_Edit":
                viewer.getTextArea().selectAll();
                break;
            case "Cut_Edit":
                viewer.getTextArea().cut();
                break;
            case "Paste_Edit":
                viewer.getTextArea().paste();
                break;

            case "Exit_programm":
                System.exit(0);
                break;
            case "Delete_Edit":
                viewer.setTextToTextArea("");
                break;
            case "Print_Document":
                viewer.getTextFromTextArea();
                new Print();

                break;

            case "About":
                viewer.aboutDialog();
                break;
            case "Font_Format":
                viewer.showFontDialog();
                break;
            case "Time_Date_Edit":
                Date date = new Date();
                viewer.setTextToTextArea(""+date);
                break;
            case "Help":
                Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
                if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
                    try {
                        desktop.browse(new URI("http://google.com"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                break;

            case "OK":


                String fontName = viewer.tFont.getText();
                String fontStyle = viewer.tFontStyle.getText();
                String fontSize = viewer.tFontSize.getText();

                viewer.dialog.setVisible(false);
                if(fontStyle.equals("Bold")) {Font newFont = new Font(fontName, Font.BOLD, Integer.parseInt(fontSize));
                    viewer.getTextArea().setFont(newFont);}
                else if(fontStyle.equals("Italic")) {Font newFont = new Font(fontName, Font.ITALIC, Integer.parseInt(fontSize));
                    viewer.getTextArea().setFont(newFont);}
                else if(fontStyle.equals("Regular")) {
                    Font newFont = new Font(fontName, Font.PLAIN, Integer.parseInt(fontSize));
                    viewer.getTextArea().setFont(newFont);
                    System.out.println(fontStyle);}






                break;

        }
        

    }


    private void newDocument() {
        String value = viewer.getTextFromTextArea();

        if(!value.equals("")) {

            int result = showDialog();
//            System.out.println(result);
            switch(result) {
                case 1:
                    viewer.setTextToTextArea("");
                    viewer.getFrame().setTitle("Notepad");
                    break;
                case 0:
                    saveAs();
                    viewer.setTextToTextArea("");
                    viewer.getFrame().setTitle("Notepad");
                    break;
            }



        }

    }


    private int showDialog() {
//Custom button text

        if(!fileName.equals("Untitled")) {
            fileName = "\n" + fileName;
        }

        Object[] options = {"Save",
                "Don't Save",
                "Cancel"};
        int n = JOptionPane.showOptionDialog(viewer.getFrame(),
                "Do you want to save changes to " + fileName,
                "Notepad",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[2]);

        return n;
    }

    private void save(){
        if (fileName=="Untitled"){
            saveAs();
        }
        else {
            String check = viewer.getTextFromTextArea();
            if (!(check==buffer)){
                saveAs();
            }
        }
    }


    private boolean saveAs() {

        String text = viewer.getTextFromTextArea();

        try {

            JFileChooser fc = new JFileChooser();
            int returnVal = fc.showSaveDialog(viewer.getFrame());

            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                FileWriter fw = new FileWriter(file);
                PrintWriter outputStream = new PrintWriter(fw);
                outputStream.println(text);
                outputStream.close();
                return true;
            }

        } catch (IOException ioe) {
            System.out.println(ioe);
            return false;
        }

        return false;
    }


    private boolean open() {

        buffer="";
        try {

            JFileChooser fc = new JFileChooser();
            int returnVal = fc.showOpenDialog(viewer.getFrame());

            if(returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();

                FileReader fr = new FileReader(file);

                BufferedReader inputStream = new BufferedReader(fr);

                String line;
                while ((line = inputStream.readLine()) != null) {
                    buffer = buffer + line + "\n";

                }

                viewer.setTextToTextArea(buffer);
                viewer.getFrame().setTitle(file.getName());
                fileName = file.toString();

                return true;
            }

        } catch(IOException ioe) {
            System.out.println(ioe);
            return false;
        }

        return false;

    }


}
